package mk.ukim.finki.wp.sep2022.model;

public enum MatchType {
    FRIENDLY,
    COMPETITIVE,
    CHARITY
}
