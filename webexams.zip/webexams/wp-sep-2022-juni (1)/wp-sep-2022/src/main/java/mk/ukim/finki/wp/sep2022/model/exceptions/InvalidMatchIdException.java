package mk.ukim.finki.wp.sep2022.model.exceptions;

public class InvalidMatchIdException extends RuntimeException {
}
