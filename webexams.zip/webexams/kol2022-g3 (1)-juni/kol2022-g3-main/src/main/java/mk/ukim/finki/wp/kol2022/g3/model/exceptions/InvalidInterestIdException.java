package mk.ukim.finki.wp.kol2022.g3.model.exceptions;

public class InvalidInterestIdException extends RuntimeException {
}
