package mk.ukim.finki.wp.kol2022.g3.model;

public enum ForumUserType {
    ADMIN,
    REGULAR,
    GOLDEN
}
