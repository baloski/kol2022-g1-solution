package mk.ukim.finki.wp.kol2022.g1.model;

public enum EmployeeType {
    ADMIN,
    REGULAR,
    CONSULTANT
}
