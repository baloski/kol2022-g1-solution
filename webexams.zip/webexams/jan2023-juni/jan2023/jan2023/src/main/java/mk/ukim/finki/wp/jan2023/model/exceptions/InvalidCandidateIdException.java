package mk.ukim.finki.wp.jan2023.model.exceptions;

public class InvalidCandidateIdException extends RuntimeException {
}
